# Driver Drowsiness Detection System

Real-time driver drowsiness detection using **MobileNetV2 Transfer Learning** and **OpenCV**.
Classifies eye states (open / closed) from a live webcam feed and triggers an audio alert
when the driver's eyes remain closed beyond a safe threshold.

---

## Results

| Metric | Score |
|--------|-------|
| Validation Accuracy | 96.4% |
| Precision (closed eyes) | 95.8% |
| Recall (closed eyes) | 97.1% |
| Alert latency | < 1.2 seconds |
| Dataset | MRL Eye Dataset (84,898 images) |

---

## Demo

> Run `python detect_drowsiness.py` — webcam opens and detection starts live.
> Eyes open → green bar. Eyes closed → yellow. Drowsiness detected → red alert.

---

## Tech Stack

| Category | Tools |
|----------|-------|
| Deep Learning | TensorFlow, Keras, MobileNetV2 |
| Computer Vision | OpenCV |
| Data Processing | NumPy, Pillow |
| Visualisation | Matplotlib, Seaborn |
| Evaluation | scikit-learn (confusion matrix, F1) |

---

## Project Structure

```
driver-drowsiness-detection/
├── train_model.py        # MobileNetV2 training with data augmentation
├── detect_drowsiness.py  # Live OpenCV webcam detection pipeline
├── evaluate.py           # Confusion matrix, classification report
├── requirements.txt      # All dependencies
├── results/
│   ├── training_curves.png
│   ├── confusion_matrix.png
│   └── sample_predictions.png
└── README.md
```

---

## How to Run

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/driver-drowsiness-detection.git
cd driver-drowsiness-detection
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Download the dataset
Download the **MRL Eye Dataset** from Kaggle:
https://www.kaggle.com/datasets/kutaykutlu/drowsiness-detection

Place images in this structure:
```
data/
├── train/
│   ├── open/      ← open eye images
│   └── closed/    ← closed eye images
└── val/
    ├── open/
    └── closed/
```

### 4. Train the model
```bash
python train_model.py
```
Saved to `models/drowsiness_model.h5`

### 5. Evaluate on validation set
```bash
python evaluate.py
```

### 6. Run live drowsiness detection
```bash
python detect_drowsiness.py
```

Optional flags:
```bash
python detect_drowsiness.py --threshold 25   # frames before alert (default: 20)
python detect_drowsiness.py --camera 1       # use external webcam
```

Press **Q** to quit.

---

## How It Works

```
Webcam Frame
    ↓
Haar Cascade Face Detection
    ↓
Haar Cascade Eye Detection (within face ROI)
    ↓
Eye region crop → Resize to 224×224 → Normalize
    ↓
MobileNetV2 → Binary classifier (open / closed)
    ↓
Consecutive closed frame counter
    ↓
Counter ≥ threshold → ALERT triggered
```

---

## Model Architecture

- **Base**: MobileNetV2 pre-trained on ImageNet (frozen)
- **Head**: GlobalAveragePooling → BatchNorm → Dense(256) → Dropout(0.4) → Dense(64) → Sigmoid
- **Fine-tuning**: Last 30 layers of MobileNetV2 unfrozen in Phase 2
- **Augmentation**: Rotation, brightness shift, horizontal flip (simulates real cabin conditions)

---

## Author

**Nallamothu Aditya Chowdary**
B.Tech CSE (AI/ML) — Tirumala Engineering College
LinkedIn: linkedin.com/in/aditya-chowdary-nallamothu-943514239
