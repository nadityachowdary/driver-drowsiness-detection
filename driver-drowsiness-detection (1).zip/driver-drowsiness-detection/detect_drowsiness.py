"""
detect_drowsiness.py
====================
Real-time driver drowsiness detection using a webcam.
Loads the trained MobileNetV2 model and monitors eye state frame-by-frame.
Triggers an audio alert when eyes are closed for more than EYE_CLOSED_FRAMES
consecutive frames.

Usage:
    python detect_drowsiness.py
    python detect_drowsiness.py --model models/drowsiness_model.h5
    python detect_drowsiness.py --threshold 25

Author : Nallamothu Aditya Chowdary
"""

import cv2
import numpy as np
import argparse
import time
import os

import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array

# ── Argument Parser ────────────────────────────────────────────────────────
parser = argparse.ArgumentParser(description="Real-Time Drowsiness Detector")
parser.add_argument("--model",     default="models/drowsiness_model.h5",
                    help="Path to trained .h5 model")
parser.add_argument("--threshold", type=int, default=20,
                    help="Consecutive closed-eye frames before alert (default: 20)")
parser.add_argument("--camera",    type=int, default=0,
                    help="Camera index (default: 0)")
args = parser.parse_args()

# ── Constants ──────────────────────────────────────────────────────────────
IMG_SIZE          = (224, 224)
EYE_CLOSED_FRAMES = args.threshold   # ~0.67 sec at 30 fps
CONF_THRESHOLD    = 0.55             # probability above this = closed eyes

# Haar cascade for face and eye detection (built into OpenCV)
FACE_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
EYE_CASCADE_PATH  = cv2.data.haarcascades + "haarcascade_eye.xml"

# Colours (BGR)
GREEN  = (0, 220, 0)
RED    = (0, 0, 220)
YELLOW = (0, 220, 220)
WHITE  = (255, 255, 255)
BLACK  = (0, 0, 0)


# ── Load Model & Cascades ──────────────────────────────────────────────────
def load_resources():
    if not os.path.exists(args.model):
        raise FileNotFoundError(
            f"Model not found at '{args.model}'.\n"
            "Train the model first: python train_model.py"
        )

    print(f"Loading model from: {args.model}")
    model = load_model(args.model)
    print("Model loaded successfully.\n")

    face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)
    eye_cascade  = cv2.CascadeClassifier(EYE_CASCADE_PATH)

    return model, face_cascade, eye_cascade


# ── Preprocess eye-region crop for model input ─────────────────────────────
def preprocess_eye(eye_img):
    eye_img = cv2.resize(eye_img, IMG_SIZE)
    eye_img = cv2.cvtColor(eye_img, cv2.COLOR_BGR2RGB)
    eye_arr = img_to_array(eye_img) / 255.0
    eye_arr = np.expand_dims(eye_arr, axis=0)   # shape: (1, 224, 224, 3)
    return eye_arr


# ── Alert function ─────────────────────────────────────────────────────────
def trigger_alert():
    """Play a system beep. Works on Windows and Linux."""
    try:
        import winsound
        winsound.Beep(1000, 300)   # Windows
    except ImportError:
        os.system("echo -e '\a'")  # Linux / Mac terminal bell


# ── Draw overlay on frame ──────────────────────────────────────────────────
def draw_overlay(frame, status, score, closed_count, alert_active):
    h, w = frame.shape[:2]

    # Status bar at top
    bar_color = RED if alert_active else (GREEN if status == "OPEN" else YELLOW)
    cv2.rectangle(frame, (0, 0), (w, 55), bar_color, -1)

    label = "ALERT! DROWSINESS DETECTED!" if alert_active else f"Eyes: {status}"
    cv2.putText(frame, label, (10, 35),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, WHITE, 2, cv2.LINE_AA)

    # Score and frame counter (bottom left)
    cv2.putText(frame, f"Confidence: {score:.2f}", (10, h - 50),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, WHITE, 1, cv2.LINE_AA)
    cv2.putText(frame, f"Closed frames: {closed_count}/{EYE_CLOSED_FRAMES}",
                (10, h - 25),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, WHITE, 1, cv2.LINE_AA)

    # Press Q to quit hint
    cv2.putText(frame, "Press Q to quit", (w - 160, h - 15),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, WHITE, 1, cv2.LINE_AA)

    return frame


# ── Main Detection Loop ────────────────────────────────────────────────────
def run_detection():
    model, face_cascade, eye_cascade = load_resources()

    cap = cv2.VideoCapture(args.camera)
    if not cap.isOpened():
        raise RuntimeError("Could not open webcam. Check camera index with --camera.")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    closed_count  = 0
    alert_active  = False
    fps_timer     = time.time()
    frame_count   = 0

    print("Starting real-time detection. Press Q to quit.\n")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame from webcam.")
            break

        frame_count += 1
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # ── Detect faces ──────────────────────────────────────────────────
        faces = face_cascade.detectMultiScale(
            gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80)
        )

        status = "NO FACE"
        score  = 0.0

        for (fx, fy, fw, fh) in faces:
            # Draw face rectangle
            cv2.rectangle(frame, (fx, fy), (fx + fw, fy + fh), GREEN, 2)

            roi_gray  = gray[fy:fy + fh, fx:fx + fw]
            roi_color = frame[fy:fy + fh, fx:fx + fw]

            # ── Detect eyes within face region ────────────────────────────
            eyes = eye_cascade.detectMultiScale(
                roi_gray, scaleFactor=1.1, minNeighbors=5, minSize=(25, 25)
            )

            for (ex, ey, ew, eh) in eyes[:2]:   # process max 2 eyes
                # Draw eye rectangle
                cv2.rectangle(roi_color,
                              (ex, ey), (ex + ew, ey + eh), YELLOW, 1)

                eye_crop  = roi_color[ey:ey + eh, ex:ex + ew]
                eye_input = preprocess_eye(eye_crop)

                # ── Model prediction ──────────────────────────────────────
                pred  = model.predict(eye_input, verbose=0)[0][0]
                score = float(pred)

                # pred close to 1.0 = closed eye (depending on class order)
                if score >= CONF_THRESHOLD:
                    status = "CLOSED"
                    closed_count += 1
                else:
                    status = "OPEN"
                    closed_count = max(0, closed_count - 1)

                break   # use first detected eye only

        # ── If no face/eye detected reset counter ─────────────────────────
        if len(faces) == 0:
            closed_count = max(0, closed_count - 1)

        # ── Alert logic ───────────────────────────────────────────────────
        alert_active = closed_count >= EYE_CLOSED_FRAMES
        if alert_active:
            trigger_alert()

        # ── FPS calculation ───────────────────────────────────────────────
        if frame_count % 30 == 0:
            fps = 30 / (time.time() - fps_timer)
            fps_timer = time.time()
            frame_count = 0

        # ── Draw overlay and show ─────────────────────────────────────────
        frame = draw_overlay(frame, status, score, closed_count, alert_active)
        cv2.imshow("Driver Drowsiness Detection — Aditya", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            print("Detection stopped by user.")
            break

    cap.release()
    cv2.destroyAllWindows()


# ── Entry point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    run_detection()
