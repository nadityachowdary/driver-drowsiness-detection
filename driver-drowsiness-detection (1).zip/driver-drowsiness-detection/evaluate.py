"""
evaluate.py
===========
Evaluates the trained drowsiness model on the validation/test set.
Generates:
  - Classification report (precision, recall, F1)
  - Confusion matrix plot  →  results/confusion_matrix.png
  - Sample predictions grid →  results/sample_predictions.png

Usage:
    python evaluate.py
    python evaluate.py --data data/test --model models/drowsiness_model.h5

Author : Nallamothu Aditya Chowdary
"""

import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.metrics import classification_report, confusion_matrix

# ── Args ───────────────────────────────────────────────────────────────────
parser = argparse.ArgumentParser()
parser.add_argument("--model", default="models/drowsiness_model.h5")
parser.add_argument("--data",  default="data/val")
args = parser.parse_args()

IMG_SIZE   = (224, 224)
BATCH_SIZE = 32
os.makedirs("results", exist_ok=True)


# ── Load model and data ────────────────────────────────────────────────────
print(f"Loading model : {args.model}")
model = load_model(args.model)

datagen = ImageDataGenerator(rescale=1.0 / 255)
gen = datagen.flow_from_directory(
    args.data,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode="binary",
    shuffle=False,
)

class_names = list(gen.class_indices.keys())
print(f"Classes       : {gen.class_indices}\n")


# ── Predict ────────────────────────────────────────────────────────────────
print("Running predictions on validation set...")
y_prob = model.predict(gen, verbose=1)
y_pred = (y_prob >= 0.5).astype(int).flatten()
y_true = gen.classes

# ── Classification report ──────────────────────────────────────────────────
print("\n=== Classification Report ===")
report = classification_report(y_true, y_pred, target_names=class_names)
print(report)

with open("results/classification_report.txt", "w") as f:
    f.write(report)
print("Report saved to results/classification_report.txt")


# ── Confusion matrix ───────────────────────────────────────────────────────
cm = confusion_matrix(y_true, y_pred)

plt.figure(figsize=(7, 6))
sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=class_names,
    yticklabels=class_names,
    linewidths=0.5,
)
plt.title("Confusion Matrix — Drowsiness Detection", fontsize=14, pad=14)
plt.xlabel("Predicted Label", fontsize=12)
plt.ylabel("True Label", fontsize=12)
plt.tight_layout()
plt.savefig("results/confusion_matrix.png", dpi=150)
plt.show()
print("Confusion matrix saved to results/confusion_matrix.png")


# ── Sample predictions grid ────────────────────────────────────────────────
print("\nGenerating sample predictions grid...")
gen.reset()
images, labels = next(gen)
preds = model.predict(images, verbose=0).flatten()

fig, axes = plt.subplots(3, 4, figsize=(14, 10))
fig.suptitle("Sample Predictions — Green=Correct  Red=Wrong", fontsize=13, y=1.01)

for i, ax in enumerate(axes.flat):
    if i >= len(images):
        ax.axis("off")
        continue
    img = images[i]
    true_label = class_names[int(labels[i])]
    pred_label = class_names[int(preds[i] >= 0.5)]
    correct    = true_label == pred_label

    ax.imshow(img)
    ax.set_title(
        f"True: {true_label}\nPred: {pred_label}  ({preds[i]:.2f})",
        fontsize=9,
        color="green" if correct else "red",
    )
    ax.axis("off")

plt.tight_layout()
plt.savefig("results/sample_predictions.png", dpi=150)
plt.show()
print("Sample predictions saved to results/sample_predictions.png")
