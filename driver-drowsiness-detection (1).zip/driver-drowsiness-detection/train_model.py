"""
train_model.py
==============
Trains a binary eye-state classifier (open / closed) using MobileNetV2
Transfer Learning on the MRL Eye Dataset.

Dataset : MRL Eye Dataset
          https://www.kaggle.com/datasets/kutaykutlu/drowsiness-detection
          Place images in:
            data/train/open/   and   data/train/closed/
            data/val/open/     and   data/val/closed/

Author  : Nallamothu Aditya Chowdary
"""

import os
import numpy as np
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import (
    Dense, GlobalAveragePooling2D, Dropout, BatchNormalization
)
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import (
    ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
)
from tensorflow.keras.preprocessing.image import ImageDataGenerator

# ── Configuration ──────────────────────────────────────────────────────────
IMG_SIZE    = (224, 224)
BATCH_SIZE  = 32
EPOCHS      = 20
LR          = 1e-4
DATA_DIR    = "data"
MODEL_PATH  = "models/drowsiness_model.h5"

os.makedirs("models", exist_ok=True)
os.makedirs("results", exist_ok=True)


# ── Data Augmentation ──────────────────────────────────────────────────────
def build_generators():
    train_datagen = ImageDataGenerator(
        rescale=1.0 / 255,
        rotation_range=15,
        width_shift_range=0.1,
        height_shift_range=0.1,
        shear_range=0.1,
        zoom_range=0.1,
        horizontal_flip=True,
        brightness_range=[0.7, 1.3],   # simulates low-light cabin conditions
        fill_mode="nearest",
    )

    val_datagen = ImageDataGenerator(rescale=1.0 / 255)

    train_gen = train_datagen.flow_from_directory(
        os.path.join(DATA_DIR, "train"),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="binary",
        color_mode="rgb",
        shuffle=True,
    )

    val_gen = val_datagen.flow_from_directory(
        os.path.join(DATA_DIR, "val"),
        target_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        class_mode="binary",
        color_mode="rgb",
        shuffle=False,
    )

    return train_gen, val_gen


# ── Model Architecture ─────────────────────────────────────────────────────
def build_model():
    # Load MobileNetV2 pre-trained on ImageNet, exclude top layers
    base_model = MobileNetV2(
        input_shape=(*IMG_SIZE, 3),
        include_top=False,
        weights="imagenet",
    )

    # Freeze base model layers — only train our custom head first
    base_model.trainable = False

    # Custom classification head
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = BatchNormalization()(x)
    x = Dense(256, activation="relu")(x)
    x = Dropout(0.4)(x)
    x = Dense(64, activation="relu")(x)
    x = Dropout(0.2)(x)
    output = Dense(1, activation="sigmoid")(x)   # binary: 0=open, 1=closed

    model = Model(inputs=base_model.input, outputs=output)

    model.compile(
        optimizer=Adam(learning_rate=LR),
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )

    print(model.summary())
    return model, base_model


# ── Callbacks ──────────────────────────────────────────────────────────────
def get_callbacks():
    return [
        ModelCheckpoint(
            MODEL_PATH,
            monitor="val_accuracy",
            save_best_only=True,
            verbose=1,
        ),
        EarlyStopping(
            monitor="val_accuracy",
            patience=5,
            restore_best_weights=True,
            verbose=1,
        ),
        ReduceLROnPlateau(
            monitor="val_loss",
            factor=0.5,
            patience=3,
            min_lr=1e-7,
            verbose=1,
        ),
    ]


# ── Fine-tuning: unfreeze last 30 layers ──────────────────────────────────
def fine_tune(model, base_model, train_gen, val_gen, initial_epochs):
    print("\n--- Fine-tuning: unfreezing last 30 layers ---")
    base_model.trainable = True
    for layer in base_model.layers[:-30]:
        layer.trainable = False

    model.compile(
        optimizer=Adam(learning_rate=LR / 10),
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )

    history_ft = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=initial_epochs + 10,
        initial_epoch=initial_epochs,
        callbacks=get_callbacks(),
    )
    return history_ft


# ── Plot training curves ───────────────────────────────────────────────────
def plot_history(history, history_ft=None):
    acc     = history.history["accuracy"]
    val_acc = history.history["val_accuracy"]
    loss    = history.history["loss"]
    val_loss= history.history["val_loss"]

    if history_ft:
        acc     += history_ft.history["accuracy"]
        val_acc += history_ft.history["val_accuracy"]
        loss    += history_ft.history["loss"]
        val_loss+= history_ft.history["val_loss"]

    epochs_range = range(len(acc))

    plt.figure(figsize=(14, 5))

    plt.subplot(1, 2, 1)
    plt.plot(epochs_range, acc,     label="Train Accuracy")
    plt.plot(epochs_range, val_acc, label="Val Accuracy")
    plt.title("Model Accuracy")
    plt.xlabel("Epoch")
    plt.ylabel("Accuracy")
    plt.legend()
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.plot(epochs_range, loss,     label="Train Loss")
    plt.plot(epochs_range, val_loss, label="Val Loss")
    plt.title("Model Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.legend()
    plt.grid(True)

    plt.tight_layout()
    plt.savefig("results/training_curves.png", dpi=150)
    plt.show()
    print("Training curves saved to results/training_curves.png")


# ── Main ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=== Driver Drowsiness Detection — Training ===\n")

    train_gen, val_gen = build_generators()
    print(f"Classes: {train_gen.class_indices}")
    # Expected: {'closed': 0, 'open': 1}  or  {'open': 0, 'closed': 1}

    model, base_model = build_model()

    print("\n--- Phase 1: Training classification head ---")
    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=EPOCHS,
        callbacks=get_callbacks(),
    )

    # Fine-tune top layers of MobileNetV2
    history_ft = fine_tune(model, base_model, train_gen, val_gen,
                           len(history.history["accuracy"]))

    # Final evaluation
    print("\n--- Final Evaluation on Validation Set ---")
    loss, acc = model.evaluate(val_gen)
    print(f"Validation Accuracy : {acc * 100:.2f}%")
    print(f"Validation Loss     : {loss:.4f}")

    plot_history(history, history_ft)
    print(f"\nModel saved to: {MODEL_PATH}")
